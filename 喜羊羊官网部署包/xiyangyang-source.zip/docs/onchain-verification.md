# XIYANGYANG 链上数据核实记录

核实日期：2026-10-18。网络：BNB Smart Chain，Chain ID `56`。本记录用于说明数据来源和展示边界，不代表完整合约安全审计。

后续核查补充：实际回购执行尚未证实；托底路径黑洞转入已逐笔核实，见 [黑洞转入摘要](onchain/burn-path-summary.md) 和 [回购执行调查](onchain/buyback-execution-investigation-128365767.md)。页面“累计黑洞销毁数量”直接读取喜羊羊的 `balanceOf(dead)`，不使用金库 `totalBurned()` 冒充整个黑洞量，也不把它计作回购销毁。以下早期快照和集成状态为当时记录；最新状态以 README 为准。

## 已确认地址

| 用途 | 地址 | 核实依据 |
| --- | --- | --- |
| 喜羊羊代币 | `0x4dda46c9dd7e794b99eebdcfd3c82bfbd3207777` | 已部署 ERC20，EIP-1167 代理 |
| 喜羊羊 implementation | `0x024f18294970b5c76c0691b87f138a0317156422` | 代理 runtime 中的 implementation 地址；Sourcify exact match |
| POP 代币 | `0xa3cfb853339b77f385b994799b015cb04b208fe6` | 代币、金库和税费处理器的 quote-token getter |
| 托底金库 | `0x24969be5ce754c517e631805931916b826b4a4f7` | `taxToken()` 对应喜羊羊；`taxProcessor.marketAddress()` 指向此金库；runtime 源码比对通过 |
| 金库 factory | `0xbc21215ead3fa513801f402bea168c2c8b655c8b` | Flap 的 vault 绑定；Sourcify exact-match 源码内含 `FloorPriceVault` |
| 指定回购接收地址 | `0x3de5f55d352b1e161392a3fcebac5c0072ffb274` | 金库 `buyBackAddress()` 及已匹配源码常量 |
| 税费处理器 | `0xf15e0b39743cc9d12a0a63cc2a2be00623026353` | 喜羊羊 `taxProcessor()`；处理器 `taxToken()` 和 `marketAddress()` 交叉核对 |
| XIYANGYANG / POP 交易池 | `0xc06924c9234b39376ea80b21aea49ae692bc5bac` | 喜羊羊 `mainPool()`；池的 `token0()` / `token1()` 分别为喜羊羊 / POP |

喜羊羊的链上 `name()` 和 `symbol()` 均为“喜羊羊”；网站中的 `XIYANGYANG` 是项目品牌英文名称。两个代币实际读取的 `decimals()` 都为 `18`，网站仍应读取 decimals，不以此历史值替代运行时查询。

## 源码和 ABI 来源

- [喜羊羊 implementation 的 Sourcify 记录](https://sourcify.dev/server/v2/contract/56/0x024f18294970b5c76c0691b87f138a0317156422?fields=all)：`src/Tax/FlapTaxTokenV3.sol:FlapTaxTokenV3`，`solc 0.8.24+commit.e11b9ed9`，`exact_match`。代币 ABI 取自此记录。
- [金库 factory 的 Sourcify 记录](https://sourcify.dev/server/v2/contract/56/0xbc21215ead3fa513801f402bea168c2c8b655c8b?fields=all)：`contracts/FFFFF.sol:TaxTokenFloorVaultFactory`，`solc 0.8.34+commit.80d5c536`，`exact_match`。同一源码文件定义其部署的 `FloorPriceVault`；金库只读 ABI 来自此源码的重新编译结果。
- [Flap 项目页](https://flap.sh/bnb/0x4dda46c9dd7e794b99eebdcfd3c82bfbd3207777) 的服务器数据提供金库和 factory 的初始发现线索；页面宣传文案未被当作链上证据。金库关系进一步通过 getter 和 runtime 核实。
- 税费处理器读取使用上述已验证代币源码中的 `ITaxProcessor` 接口。处理器代理的 implementation 为 `0x753b07e818840c2d2dcc7a31db02628976a26518`，本次未获得其可验证实现源码。

地址、精选只读 ABI、原始响应和源码的 SHA-256 保存于 [source-provenance.json](onchain/source-provenance.json)。交易池只核对了池地址和代币成员关系，没有据此声称完成交易池源码审计。

## 金库 Runtime 比对

将 factory 的原始 `stdJsonInput` 用 `solc 0.8.34+commit.80d5c536` 重新编译，优化器关闭，`runs: 200`，`remappings: []`，仅扩展 `outputSelection` 以取得 `FloorPriceVault` 的 ABI、runtime 和 `immutableReferences`。

链上与编译结果均为 **15,103 字节**。只将编译器明确列出的 15 个 immutable 区间归零，其余字节包含 metadata 均逐字节比较，结果相同。读取到的 immutable 对应喜羊羊地址、creator、`floorAmount = 30000000 × 10^18`、`floorAmountRaw = 30000000`。

| 对象 | Keccak-256 |
| --- | --- |
| 区块内实际 runtime | `0x1f8d7a482253dfe13c4876c4668ecb58c464bb5035f2d9056ebb811626bb1c9a` |
| 编译 runtime / 归零 immutable 后的链上 runtime | `0x52dc734fe79ac477fa85392eba3b0f924a5088ea1ed0b286040a60dddfd321c8` |

比对结果、全部 immutable 位置和值、编译设置及哈希见 [vault-runtime-proof.json](onchain/vault-runtime-proof.json)。

## 可接入的数据与单位

| 展示项 | 已确认读取方式 | 解释 |
| --- | --- | --- |
| 托底金库储备 | 金库 `vaultBalance()`，selector `0x0bf6cc08` | 等价于 `POP.balanceOf(金库)`；按 POP 实际 decimals 格式化 |
| 当前托底价 | 金库 `currentPricePerTokenRaw()`，selector `0x857155be` | 返回 `uint256`，固定 18 位小数的 `POP / 每枚 XIYANGYANG`；前端直接读取此 getter |
| 回购接收钱包 POP 余额 | `POP.balanceOf(buyBackAddress())` | 地址和余额可核实，但其余额不能直接认定为项目当前可执行的专用回购资金 |

已匹配源码中的价格计算为 `vaultPOP × 10^18 / stageRemaining()`，其中 `stageRemaining = floorAmount - (totalBurned % floorAmount)`。这是源码证据，页面读取使用上述价格 getter，不使用前端自拟公式。`totalPOPReserved()` 是合约内部记账 checkpoint，不能代替实时 POP 余额。

## 历史快照

参考区块：`128347578`，区块哈希 `0x63aa026187b01e24c6edc5d797b7e8afe0c24042585a6218600e223fda90859c`。区块时间为北京时间 `2026-10-18 18:37:53`，读取完成时间为北京时间 `18:37:55.158`。

以下只是该区块的历史例子，**不供页面作为实时数据兜底**：

- 金库储备：`39,457,710.89152857411447807 POP`。
- 当前托底价：`1.31611285403617039 POP / XIYANGYANG`。
- 指定接收钱包余额：`13,153,825.449854255093759759 POP`，没有核实为项目专用或可执行回购资金。

[verified-snapshot-128347578.json](onchain/verified-snapshot-128347578.json) 保留 43 次 getter 调用的地址、calldata、参数和无损原始结果；runtime 大字符串已移除，保留字节数、Keccak-256、SHA-256 和代理 implementation。公共 RPC 可能裁剪历史状态，后续应读取新的当前区块，不反复依赖此历史区块。

## 仍未确认的语义

- 指定回购接收地址在快照中 `eth_getCode = 0x`，没有合约 runtime，是普通钱包形态；这不能证明该地址没有外部控制或执行程序。没有证据证明其中所有 POP 专供喜羊羊，或当前余额就是可执行回购资金。因此“回购可用资金”继续待接入，已确认地址可提供浏览器查询。
- 已匹配金库的 `receive()` 会将自上次 checkpoint 后增加的 POP 的 25% 转给 `buyBackAddress`。没有在该金库源码中发现“下跌 5% 自动回购”的基准价格、阈值比较或买入执行逻辑；这项规则和自动执行保证继续未核实。
- `totalBurned()` 只在金库 `swap()` 兑换销毁路径中增加，不能标为累计回购销毁；即使快照中它恰好等于 dead 地址余额，也不改变该接口语义。网站保持只读，不提供 `swap()` 或授权入口。
- `floorAmountRaw = 30000000` 是**每阶段**额度。源码通过 `totalBurned % floorAmount` 计算阶段余量，不能解释成生命周期最多托底 3000 万枚。
- 买入和卖出税 getter 均为 `200 bps = 2%`。项目提供的 `1.5% / 0.5%` 是名义分配描述。处理器快照 `feeConfig()` 含 `feeRate: 1000`、`marketBps: 10000`、`deflationBps/lpBps/dividendBps: 0`；其实现源码未核实，不能据此确认净到账比例，亦不自行推导新的净费率。
- 未接入可靠美元报价、自动回购执行记录或累计回购销毁数据。相应栏目保留待接入，不使用项目宣传数字或历史钱包余额替代。
