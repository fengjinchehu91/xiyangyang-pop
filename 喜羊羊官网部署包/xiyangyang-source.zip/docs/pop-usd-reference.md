# POP 美元参考估值

页面配置位置：`src/config/quotes.ts`。美元值均为参考估值，不是交易、托底兑付或保本承诺。

## 来源核对

- POP：`0xa3cfb853339b77f385b994799b015cb04b208fe6`。
- USDT（BSC）：`0x55d398326f99059ff775485246999027b3197955`。
- PancakeSwap V3 POP/USDT 池：`0xe5ce5bc4785cd2a246151364f5a190cee3fdb142`。
- 链上 `token0()` 为 USDT、`token1()` 为 POP，`fee()` 为 100，`factory()` 为 `0x0BFbCF9fa4f9C56B0F40a671Ad40E0805A091865`；工厂 `getPool(USDT, POP, 100)` 返回上述池。
- 工厂地址可对照 PancakeSwap 官方文档：https://developer.pancakeswap.finance/contracts/v3/addresses 。
- API 文档：https://docs.dexscreener.com/api/reference 。
- 请求：https://api.dexscreener.com/latest/dex/pairs/bsc/0xe5ce5bc4785cd2a246151364f5a190cee3fdb142 。
- 可视来源：https://dexscreener.com/bsc/0xe5ce5bc4785cd2a246151364f5a190cee3fdb142 。

解析器只接受该池、该资产身份、BSC/PancakeSwap V3 及不少于 50,000 USD 的报告流动性。使用 `priceUsd` 十进制字符串，不把价格转换成浮点数计算储备。报价请求每 30 秒随金库刷新，超过 60 秒不用于显示美元估值。

DEX Screener 没有在此响应中提供行情更新时间。因此页面明确标注“报价获取时间”，不把 `pairCreatedAt` 或客户端获取时间当成交易市场更新时间。

## 两种价格口径

1. 用户指定主展示口径：金库实际 POP 数量 × 当前 POP/USD 参考报价 ÷ 30,000,000 XIYANGYANG。
2. 补充链上口径：已核实金库 `currentPricePerTokenRaw()`，单位 POP / XIYANGYANG，使用当前阶段剩余数量。

两种口径分开展示。近 48 小时归集的美元金额同样按当前报价计算，不代表转入时的历史美元成本。无有效报价时保留 POP 数量，美元值显示缺失，不按零处理。
