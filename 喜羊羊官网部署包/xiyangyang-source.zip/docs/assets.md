# 素材来源

- `public/brand/logo.webp`、`favicon.png`：用户提供的 `/Users/fengjinchehu/Desktop/04f72f63-c1fe-4cea-bdfc-a2cae3de4289.png`，仅缩放和格式转换，保留 Alpha。
- `public/brand/mascot.webp`：内置 ImageGen 参考原始 Logo 生成独立透明角色。原始 PNG 和完整提示词保留在同目录。
- `public/brand/landscape.webp`：内置 ImageGen 参考已选首页效果图生成独立山水。原始 PNG 和完整提示词保留在同目录。
- `public/brand/pop.png`：Trust Wallet 公开资产库中与用户提供的 POP 合约地址对应的品牌标识。来源：https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0xA3cfB853339b77F385B994799B015cB04b208Fe6/logo.png 。仅用于品牌识别，不代表合作或背书。
- `public/brand/pop-medallion.webp`、`.png`：按用户要求，内置 ImageGen 参考上述原标识制作透明绿金徽章，保留白色几何 POP 符号；与网站生态绿和金色呼应。原标识保留，生成提示词见 `public/brand/pop-medallion-provenance.md`。这是网站品牌呈现，不宣称替换官方标识或新增合作背书。
- `public/fonts/manrope-*.ttf`：Google Fonts 分发的 Manrope，SIL Open Font License；授权见同目录 `OFL.txt`。
- 标准界面图标：Lucide React，ISC 许可。

所有页面图片均本地存储。未引用远程价格图片或把整张 UI 效果图放入网站。
