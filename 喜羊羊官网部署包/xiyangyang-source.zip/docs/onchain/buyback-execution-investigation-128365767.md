# 指定回购接收地址的执行记录核查

核实日期：2026-10-18。仅调查本项目已经核实的指定回购接收地址，不将金库归集当作实际回购或销毁。

## 范围及结果

- 网络：BNB Smart Chain，Chain ID `56`。
- 指定接收地址：`0x3de5f55d352b1e161392a3fcebac5c0072ffb274`。
- 项目代币：`0x4dda46c9dd7e794b99eebdcfd3c82bfbd3207777`；POP：`0xa3cfb853339b77f385b994799b015cb04b208fe6`。
- 固定区块范围：金库创建区块 **128169574** 至确认区块 **128365767**（查询时最新区块减 20）。
- 准确时间：北京时间 **2026-10-17 20:22:30 至 2026-10-18 20:54:22**。
- 查询结束后再次读取结束区块，哈希仍为 `0xfc36f1c5d3de3edb108a902d3d6bc540a9c4011bd1f2bfff03ba5fa74cd0dd48`。

完整 80 个区间查询均成功，无缺段：

| 检查项 | 该地址在上述区块范围的记录数 |
| --- | ---: |
| POP 向外 `Transfer` | 0 |
| XIYANGYANG 转入 `Transfer` | 0 |
| XIYANGYANG 转出 `Transfer` | 0 |

因此，本次没有找到可归属到该接收钱包、可以继续关联实际买入或销毁的候选转账交易。**不能据此把项目累计实际回购、项目累计回购销毁量标为 0；这些全项目统计仍未接入。**

## 两个节点一致的账户状态

在同一确认区块 `128365767`，BNB 官方 RPC 与 PublicNode 返回一致：

| 状态 | 结果 |
| --- | --- |
| `eth_getTransactionCount` | `0x0`，nonce 为 0 |
| `eth_getCode` | `0x`，没有合约代码 |
| 原生 BNB 余额 | 0 |
| XIYANGYANG 余额 | 0 |
| POP 余额 | 16,145,083.122025401019700370 POP |
| POP / XIYANGYANG 实际 decimals | 均为 18 |

nonce 为 0 可以确认该 EOA 截至该区块没有直接发起过已确认交易。它不能排除其他地址、第三方代付交易或站外系统的动作。POP 余额是账户持有量，不能标成已回购投入或已销毁金额。

## 证据与交叉验证

标准事件：`Transfer(address indexed from,address indexed to,uint256 value)`，topic `0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef`。

历史节点 `https://rpc-bsc.48.club` 按每段不超过 5000 区块，执行两种过滤，各完成 40 段：

1. `address = [POP, XIYANGYANG]`，`from = 指定接收地址`，检查两币所有转出。
2. `address = XIYANGYANG`，`to = 指定接收地址`，检查该代币全部转入。

账户状态来自 `https://bsc-dataseed.bnbchain.org` 与 `https://bsc-rpc.publicnode.com`，固定区块、账户 nonce、代码、余额及精度均匹配。

另以历史区块 `128351613` 的已知金库归集交易作阳性对照：相同 `address = [POP, XIYANGYANG]` 数组过滤能返回真实 POP `Transfer`，且与 BNB 官方 RPC 的交易 receipt 对应日志逐字段匹配。这证明历史事件检索与多地址过滤实际可用；对照记录仍是归集，不是买入或销毁。

金库创建交易 [0xcc8619…b5074](https://bscscan.com/tx/0xcc8619b905f392957e26144e1a382823eae82a70b435e0b2ea19988d7c2b5074) 再次由 BNB 官方 RPC 与 48.club 的 receipt 交叉验证，状态成功，区块及哈希一致；factory 的 `VaultCreated` 事件对应本项目税币与金库。PublicNode 对该旧 receipt 提示需要 archive token，已保留该错误，没有当作“没有交易”。

[结构化证据](buyback-execution-investigation-128365767.json) 保留全部查询区间、响应哈希、精确窗口、两个节点的账户原始响应、创建 receipt 交叉核实与所有限制。研究脚本及完整原始 RPC 响应在本机 `/tmp/xyy-buyback-investigation/`。

## 展示边界

可展示：**“在已核实接收地址及上述区块范围内，未发现 POP 支出或 XIYANGYANG 转入、转出记录。”**

仍待接入：项目范围的实际回购投入、回购成交记录、累计回购销毁数量，以及下跌 5% 自动执行的参考价格和触发接口。需要可归属的执行钱包、自动执行合约、策略接口或交易哈希，才能进一步核实。

本次没有完整枚举全部原生币来往和任意内部调用，也没有排除其他钱包或交易场所发生行为。历史零结果来自一个可用历史日志节点；结束区块哈希、项目创建关系及账户状态已独立复核，但不能把这一范围的“未发现”扩大成全项目“从未执行”。
