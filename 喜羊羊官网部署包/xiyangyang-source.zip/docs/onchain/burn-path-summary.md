# 喜羊羊黑洞转入与回购销毁核对

完整扫描范围：部署区块 `128169574` 至 `128366352`，结束区块北京时间为 `2026-10-18 20:58:45`。这是历史核实记录，不能作为页面实时值兜底。

## 核实结果

| 项目 | 结果 |
| --- | --- |
| 喜羊羊转入 `0x...dEaD` 的 Transfer | 8 笔，合计 `19,508 XIYANGYANG` |
| 金库 `TokenFloored` | 8 笔，tokenAmount 合计 `19,508 XIYANGYANG` |
| 金库 `totalBurned()` | `19,508 XIYANGYANG`，与上述事件合计一致 |
| dead 地址余额 | `19,508 XIYANGYANG`，与转入合计一致 |
| 转入零地址的 Transfer / 零地址余额 | `0 / 0` |
| 喜羊羊 `TokensBurned` 事件 | 未发现，完整扫描范围内为 0 条 |
| `totalSupply()` | 仍为 `1,000,000,000 XIYANGYANG`，相对初始铸造减少 `0` |
| 可确认的回购销毁记录 | 未核实；上述 8 笔全部是用户托底兑换 |

8 笔成功交易的目标均为金库 `0x24969be5ce754c517e631805931916b826b4a4f7`，调用 selector 均为 `0x94b918de = swap(uint256)`。逐笔 receipt 内的喜羊羊 `Transfer(user,dead,amount)` 与金库 `TokenFloored(user,tokenAmount,popAmount,newPrice)` 在同笔交易中匹配。

| 区块 | XIYANGYANG 数量 | 交易 |
| --- | ---: | --- |
| 128169704 | 10,000 | [0x2516ade2...e66fb40](https://bscscan.com/tx/0x2516ade219b281247d6ba0add4059f7bb79ec25d4734f364cde7932f5e66fb40) |
| 128169751 | 7,000 | [0x1a945d69...da56a6b](https://bscscan.com/tx/0x1a945d699f3bd53e5ebac5f4adbe3fc22029339445bd18e577bc7ac3bda56a6b) |
| 128169825 | 815 | [0x7774f8ab...16f49f4](https://bscscan.com/tx/0x7774f8ab0280716a929de34881c537c890dbbd3ca8936e96fc125700d16f49f4) |
| 128173521 | 5 | [0xb6831f49...a8a83e6](https://bscscan.com/tx/0xb6831f4913498503483d2c8dd3c854215ae8196c93bca5120f73272c0a8a83e6) |
| 128174075 | 52 | [0x205546b0...233e3dc](https://bscscan.com/tx/0x205546b05ce97efcc463fc704c96a0d1d6209ef196535c4ffa36eda74233e3dc) |
| 128174417 | 536 | [0x6b050935...d8c589e](https://bscscan.com/tx/0x6b050935151d4c3f06cf2d63624dd8f76f9f01286f6bdc87e8657598fd8c589e) |
| 128180920 | 1,000 | [0x213b82d8...4a18a92](https://bscscan.com/tx/0x213b82d8de26b24e492cd20d4d7be7a73c58c6b91d5a007ca4de03a5f4a18a92) |
| 128198318 | 100 | [0x740c9893...3ad1a81](https://bscscan.com/tx/0x740c98938d986f6b3ebd16d6d0ab9632a4207e86cc43583d8e193ecd13ad1a81) |

## 供应量与接口语义

已验证 token 在 `initialize()` 调用一次 `_mint(msg.sender,maxSupply)`。其具体 implementation 没有调用继承的 `_burn()`，也没有公开 burn 方法；`TokensBurned` 只有接口声明，没有 emit 调用。普通 `_transfer` 禁止转入零地址，但允许转入 dead，执行时只改变余额，不减少 `_totalSupply`。

金库 `swap()` 的路径为：递增 `totalBurned`，将用户喜羊羊通过 `transferFrom` 转入 dead，再向用户支付 POP 并发出 `TokenFloored`。因此可展示的准确指标是 **“托底路径累计转入黑洞”**，不能标成“回购销毁”，也不能描述为 `totalSupply` 已减少。

建议 API 将 `vaultRedemptionBurned` 和 `vaultRedemptionRecords` 与 `verifiedBuybackBurned`、`verifiedBuybackRecords` 分开。前者实时读取金库 `totalBurned() -> uint256`，按喜羊羊实际 decimals 格式化；记录读取 `TokenFloored(address indexed user,uint256 tokenAmount,uint256 popAmount,uint256 newPrice)`。后者继续保留未核实状态；没有证明时不得以 0 或托底兑换记录填充。

完整原始日志、逐笔 calldata 与 receipt 摘要、三类日志区块覆盖证明、已验证源码依据、实时读取建议字段和历史值见 [burn-path-audit-128366352.json](burn-path-audit-128366352.json)。现有源码与金库 runtime 证明见 [onchain-verification.md](../onchain-verification.md)。本次没有添加任何兑换操作。
