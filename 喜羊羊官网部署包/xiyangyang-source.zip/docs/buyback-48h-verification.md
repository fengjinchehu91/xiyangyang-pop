# 回购资金归集：48 小时链上核实

核实日期：2026-10-18。网络：BNB Smart Chain，Chain ID `56`。

## 已核实的历史窗口

北京时间 **2026-10-16 19:52:02 至 2026-10-18 19:52:02**，区块 `127973572–128357457`：

- 金库 `0x24969be5ce754c517e631805931916b826b4a4f7` 转入指定回购接收地址 `0x3de5f55d352b1e161392a3fcebac5c0072ffb274` 的 POP：**40 笔，13,600,501.640874421913514334 POP**。
- 同窗口接收地址来自其他地址的 POP 入账：**0 笔**。
- 同窗口接收地址向外的 POP 转账：**0 笔**。
- 扫描开始时读取的接收钱包当前 POP 余额亦为上述数量。它是当时 `latest` 余额，不声称它是历史结束区块的固定余额。

首笔：[2026-10-17 20:22:34，区块 128169583](https://bscscan.com/tx/0xb7abee9d311bf9f20d42f52928f6de145856b53ec9aded95d694c3df261930a5)。末笔：[2026-10-18 19:08:09，区块 128351613](https://bscscan.com/tx/0xa3d573e2b76a765dec34b910f020c0622accdd83b02795b6166e3593444fc403)。

## 统计口径与边界

网站展示的是**金库归集到指定接收地址的 POP 累计转入额**，而不是项目当前可执行的回购可用余额，也不是已经完成的回购或销毁金额。美元数值只能使用当前可靠 POP 报价换算，不能称为历史转账时的美元投入额。

已匹配的金库源码 `receive()` 将相对 checkpoint 增加的 POP 的 25% 转给 `buyBackAddress()`。该地址是源码固定接收地址，尚未核实其余额由独立合约保证专供本项目。没有查得可证明“下跌 5% 自动买入销毁”的执行接口及条件；这部分仍待接入。

## 证据与查询

POP 代币：`0xa3cfb853339b77f385b994799b015cb04b208fe6`；实际读取 `decimals() = 18`。

历史日志 RPC：`https://rpc-bsc.48.club`。按每段不超过 5000 区块查询标准 `Transfer(address indexed from, address indexed to, uint256 value)`，两个过滤器各完成 77 段，均无错误：

1. `from` 为金库或接收钱包，统计金库转入及接收钱包转出。
2. `to` 为接收钱包，确认其全部 POP 入账来源。

独立核对 RPC：`https://bsc-dataseed.bnbchain.org`。40 笔交易 receipt 中的地址、topics、金额、logIndex 和 blockHash 逐字段匹配，**40/40 通过**。该节点裁剪了旧状态，尝试历史结束区块 `balanceOf` 返回 `missing trie node`；没有以零替代错误。

另核实金库创建交易 [0xcc8619…b5074](https://bscscan.com/tx/0xcc8619b905f392957e26144e1a382823eae82a70b435e0b2ea19988d7c2b5074)：区块 `128169574`，北京时间 `2026-10-17 20:22:30`，成功 receipt 中的 factory `VaultCreated(taxToken,vault,creator)` 事件明确对应本项目的代币及金库。factory 的已验证源码是在 `new FloorPriceVault` 成功后发出此事件。

[压缩历史证据](onchain/buyback-48h-128357457.json) 保留区块边界、40 笔金额与交易哈希、交叉核实状态及限制。此文件仅供核实，前端不读取它作为实时数值或失败兜底。

## 实时读取实现

- `src/data/buybackFlows.ts` 导出 `readBuybackFlows()`，查询标准 POP `Transfer`，仅统计已核实金库到接收地址的入账。
- `VITE_BSC_HISTORY_RPC_URL` 可替换历史节点，默认 `https://rpc-bsc.48.club`；主链 RPC 沿用现有 `VITE_BSC_RPC_URL`。两个节点均校验 Chain ID `56`。
- 取主链最新区块减 20 个区块的固定结束点，以其时间向前计算精确 48 小时。首先验证上述创建交易的 receipt，再二分定位时间边界。初次扫描从“48 小时边界区块与金库创建区块二者较大值”开始，金库创建前不可能产生其合约执行的转出事件；原始完整 48 小时扫描也确认创建前没有相关转出。不凭交易池创建时间截断。
- 每段最多 5000 区块，最多四个并发请求。所有分段成功、结束区块哈希复核成功后才提交结果；任一失败整项显示暂未获取，可重试。
- 内存缓存已读取日志。后续刷新核实旧结束区块哈希，仅补查增量及 128 个区块重叠区，删除窗口外日志并按交易哈希与日志序号去重。旧区块哈希改变时重新完整扫描。
- 数量始终为 `bigint`，精度来自真实 ERC20 元数据查询。完全成功且无匹配事件时才显示零。
- `src/hooks/useBuybackFlows.ts` 单独读取，页面可见时每 60 秒更新；全局请求去重，支持手动重试，不阻塞金库余额和报价读取。
- `windowStart`、`windowEnd`、`updatedAt` 均为毫秒时间戳，`fromBlock`、`toBlock` 为 `bigint`。`windowStart` 始终是实际 48 小时边界；若金库较新，`fromBlock` 是经核实的金库创建区块。

验证：`npm test -- tests/buybackFlows.test.ts`。覆盖时间边界、真实精度、大整数、完整分段、错误重试、并发去重、窗口裁剪、增量重扫及区块哈希变化。
