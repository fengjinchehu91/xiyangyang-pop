# Design QA

final result: passed

Latest user revision: the previously added redemption-history section is simplified to **累计黑洞销毁数量**. It now reads the actual XIYANGYANG balance of the verified dead address, rather than the vault redemption counter. Long explanatory copy and the inline transaction list have been removed from that section. Scope stays in the FAQ; actual buyback/buyback-burn metrics remain unconfigured. Historical investigation evidence is retained under `docs/onchain/`, not used as a live fallback. The unused history reader/hook added during this turn were removed to avoid unnecessary scans. Latest test count: 70 passing.

Final simplified-count evidence: `docs/screenshots/blackhole-count-final.jpg` (normal 483px browser viewport) and `blackhole-count-desktop.jpg` (1440px test). The live count reads 19,508 XIYANGYANG; refresh works, the old history list is absent, and Chinese plus English at 320px have no horizontal overflow. A fresh browser check after the final reload found no new errors/warnings. Temporary viewport overrides were reset.

Latest revision (2026-10-18): reserves now show POP quantity, current POP/USD reference and USD value. The project-requested USD backing reference (reserve USD / 30 million) is separate from the actual contract POP getter. The third metric is rolling 48-hour POP funding collected from the verified vault, not an available balance or executed buybacks. POP now uses a coordinated green/gold medallion; DeBox and QQ 1097270072 are live. Older integration notes and screenshots below are historical.

## Latest revision checks

- Screenshots: `valuation-treasury-desktop.jpg`, `valuation-treasury-mobile.jpg`, `valuation-ecosystem-desktop.jpg`, `valuation-community-mobile.jpg`, `valuation-tablet.jpg` and `valuation-mobile-en-320.jpg` in `docs/screenshots/`.
- Live browser reads succeeded for reserves, contract price, validated POP/USD reference and complete 48-hour funding history. During testing an incremental scan picked up a new transfer (40 to 41 transactions), demonstrating values are not fixed fixtures.
- Quote retrieval time is labeled as retrieval, not market update time. POP-only values survive missing/failed prices. USD reference calculations remain bigint-based.
- First full funding scan was verified against real RPC; subsequent scans use cached history plus overlapping new ranges. Failed segments do not submit partial totals; changing treasury/recipient disables the old deployment's statistics.
- Read-only review caught possible mixing under environment overrides; a source-identity guard and regression test now prevent it.
- Desktop 1440, tablet 768 and phones 390/320 were checked. A visual review found that tablet three-column values could wrap within decimals, despite no horizontal overflow. Treasury now uses one column below 1100px and keeps each primary number unbroken.
- New DeBox destination matches the supplied URL exactly, QQ copy feedback works, and the mobile mascot is in normal layout without covering contacts.
- Exactly three treasury metrics; no exchange form, input, select, wallet authorization or contract write.
- 68 tests pass. Type check and production build pass. Browser error/warning log was empty.

## Visual authority

- Source preview: `/Users/fengjinchehu/.codex/generated_images/01a14db7-d8aa-7f13-88f7-940c3d85b36b/exec-4d67e839-390d-4768-a18b-5cc18c751bb2.png` (855 × 1840).
- The latest user-authored implementation brief overrides the older preview's centered badge Hero, saturated treatment, funding promotion and former section order. The implemented left-copy/right-mascot Hero, warm white background, three-metric treasury, POP ecosystem and on-chain section are intentional requirements, not fidelity defects.
- Brand fidelity retained: original logo, fluffy sheep, gold horns, POP sunglasses, green scarf, blue-green mountain landscape and small gold accents. Dedicated real raster assets are used; the full preview is not served as a page background.

## Evidence

- Browser: Codex in-app browser, local Vite server at `http://localhost:5173/`.
- `docs/screenshots/desktop-zh.jpg`: full page, 1431 × 4469; CSS viewport 1440 × 1000, scrollbar excluded by full-page capture.
- `docs/screenshots/desktop-hero.jpg`: 1440 × 1000 viewport capture.
- `docs/screenshots/desktop-treasury.jpg`: focused desktop treasury and surrounding page.
- `docs/screenshots/mobile-zh.jpg`: full page at CSS viewport 390 × 844, captured width 381 excluding scrollbar.
- `docs/screenshots/mobile-hero.jpg`: focused mobile Hero.
- `docs/screenshots/mobile-treasury.jpg`: all three vertical metrics and units.
- `docs/screenshots/tablet-zh.jpg`: 759 × 4399 full page at CSS viewport 768 × 1024.
- `docs/screenshots/mobile-en-320.jpg`: English narrow layout, CSS viewport 320 × 760. Captured during keyboard focus testing, so the visible skip-link/focused menu state is intentional test evidence.
- `docs/screenshots/reference-comparison.jpg`: old preview and current full desktop render normalized to 600 px per column, preserving image aspect ratios and aligning page tops. Compared in one image. Expected latest-brief changes are evaluated separately from brand continuity; no pixel-identical claim is made.
- `docs/screenshots/responsive-preview.jpg`: actual desktop Hero and mobile treasury shown together.
- Focused evidence includes Hero composition, treasury label/value/unit completeness, flow percentages and known/pending transparency rows. Full-page thumbnails alone were not used to assess small text.
- All image assets reported loaded in the browser. No blank image regions were observed.

## Required fidelity surfaces

- Typography: self-hosted Manrope for Latin/numerals, system Chinese sans fallback. Headings, long English copy and address labels remain inside their containers at 1440, 768, 390 and 320 CSS px. Letter spacing is zero.
- Layout: desktop maximum content width 1200 px; two-column Hero, four issuance parameters, exactly three desktop treasury metrics; vertical treasury on mobile. Body sections are full-width, with restrained framed flow branches only.
- Colors: warm white `#FAFBF7`, primary green `#12654A`, deep green `#073E32`, pale mint and gold `#C9A34A`. Secondary text contrast was strengthened after the first inspection.
- Images: independently generated landscape and transparent mascot, original brand badge and source POP logo. No mascot stretching or code-drawn replacement. Landscape cropping is intentional background treatment.
- Content: latest supplied headline, supply, separate buy/sell tax, token-denominated limit and 1.5%/0.5% flow are accurate. No unverified funding, incubation, audit or Binance backing claim is displayed.

## Interaction and data checks

- Header/Hero anchors reach their sections; settled targets remain below the sticky header.
- Mobile menu opens, closes after link selection and supports Escape with focus returned to its toggle.
- Chinese/EN toggle updates visible copy, `lang`, title and remembered language.
- Contract and QQ copy controls produce explicit success feedback; full configured strings are passed to `navigator.clipboard.writeText`.
- Confirmed external links preserve exact supplied destinations and use `noopener noreferrer`; unknown treasury, buyback, burn and pool destinations have no active placeholder links.
- FAQ works with the keyboard. Focus outline measured 3 px in the browser.
- `prefers-reduced-motion` disables authored animation, smooth scrolling and transitions through CSS.
- DOM checks: three treasury metrics; zero `form`, `input` or `select` elements; no exchange/payment/estimated-received controls; no wallet connection.
- DOM checks at 1440, 768, 390 and 320 px: document scroll width does not exceed viewport width; no overflowing visible main-content elements.
- Browser console: no errors or warnings in the checked page.
- Default treasury and backing price use verified BSC reads at one block. Buyback available funds, cumulative buyback burns and recent buybacks remain unconfigured; no wallet total, guessed formula or missing value is substituted.
- 29 Vitest tests pass, including recipient-vs-available-funds guards, same-block verified vault reads, price interface precision, mismatched asset identity and read-only ABI enforcement, in addition to original precision/failure/retry/quote tests.
- Type check and production build pass. Mechanical design detector returned an empty finding list.

## Comparison history

1. Initial desktop/mobile render: brand proportions and primary layout correct. Found low contrast in a few secondary light-surface notes and a small label over detailed landscape.
2. Darkened secondary note colors and added a quiet pale surface behind the network label. Recaptured final desktop/mobile layouts; no remaining actionable P0/P1/P2 findings.
3. A fresh read-only finish reviewer inspected desktop/mobile evidence and the data/configuration implementation, returning `ship` with no actionable P1/P2 findings.
4. On-chain integration review found one P2: a mechanism card still described automatic execution as implemented. Both translations now explicitly mark execution logic unverified. The same reviewer confirmed that finding resolved with no remaining findings in the focused review. Live treasury renders show two successful reads and one pending available-funds metric, with no overflow or wallet prompt.

## Remaining integration limits

The treasury address, deployed source/units, designated recipient and pool have been verified. The browser successfully reads real reserves and the 18-decimal backing-price getter. Project-dedicated available buyback funds, buyback execution/5% trigger, cumulative buyback burns, recent buyback and a reliable USD feed remain unverified. The source's 30-million amount is per stage, and vault `totalBurned()` is not treated as cumulative buyback burn. The new source evidence is saved separately from the live read path.

## Implementation checklist

- Local app runs; build, type check and tests pass.
- Responsive screenshots saved and inspected.
- Read-only treasury and pending states are accurate.
- Configuration example and startup/integration instructions delivered in `README.md` and `.env.example`.
- Local only. No publishing or contract writes performed.
