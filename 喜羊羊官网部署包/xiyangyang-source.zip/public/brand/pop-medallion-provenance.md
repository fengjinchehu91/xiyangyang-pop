# POP Medallion Asset

- Created: 2026-10-18
- Method: built-in `image_gen` image edit; original POP emblem as the identity reference and XIYANGYANG mascot logo as the material/palette reference.
- Inputs: `public/brand/pop.png`, `public/brand/logo.webp`.
- Output: `pop-medallion.png`, `pop-medallion.webp`, each 1024 x 1024 with genuine alpha transparency. Original `pop.png` is unchanged.
- Website purpose: a decorative emerald jade carrier with a thin gold rim, harmonizing the existing POP emblem with the site's emerald, warm-white and gold palette. This is a site-specific presentation asset, not a claim of a new official POP logo.
- Quality check: emblem orientation and open angular silhouette visually matched to the existing source; entire medallion visible; no sheep, lettering or extra symbols. Because the input emblem is a tiny raster, the rendered raised edges are stylistic, not a new authoritative vector master.
- Post-processing: proportional resize and PNG/WebP encoding with Sharp; no emblem redraw.

## Generation Prompt

Use case: precise-object-edit.
Asset type: production website brand image asset, isolated transparent PNG, square approximately 1024 x 1024.
Primary request: Beautify only the carrier behind the POP / Zypher logo in the first reference. Make a premium restrained emerald jade circular medallion with one slim warm-gold beveled outer rim. Preserve EXACTLY the recognizable white angular interlocking POP / Zypher emblem in reference image 1: identical open angular silhouette, orientation, internal turns, proportion, geometry, no redrawing into a letter Z, no added marks. Center a crisp white softly raised version of that EXACT emblem on the smooth deep emerald jade face.
Input images: Image 1 is edit target and authoritative emblem identity. Image 2 is supporting material and palette reference ONLY: the jade-green base, subtle warm-gold polished border and softly lit 3D mascot material style; do not add the sheep, Chinese lettering, landscape, or any other motifs from image 2.
Composition: single circular medallion front view with exceptionally slight material depth, whole medallion fully visible, equal 8 percent transparent padding on all sides. Emblem has generous negative space. Carrier occupies about 84 percent of canvas, emblem about 47 percent of canvas.
Lighting: refined soft studio light from upper left, fine natural rim highlights, subtle depth. Gold is thin and restrained. Emerald jade is deep green with faint natural material variation, smooth readable face.
Text: absolutely NO words, letters, numerals, ticker symbols, captions, watermarks.
Constraints: actual alpha transparent background, no ground plane, no opaque square, no surrounding shadow rectangle, no coin-text decoration, no additional inner icons, no clouds, no geometric decoration, no new symbol design, no mascot. Make the original emblem very crisp and faithful.
