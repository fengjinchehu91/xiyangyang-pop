# Mascot Asset

- Input: user-provided `04f72f63-c1fe-4cea-bdfc-a2cae3de4289.png` logo.
- Method: built-in image generation tool, reference-guided transparent extraction and lower-torso completion.
- Source: `mascot-source.png`, 1254 x 1254 pixels, RGBA.
- Web asset: `mascot.webp`, 1100 x 1100 pixels, alpha preserved, WebP quality 88.
- Intended use: project-local XIYANGYANG website hero and brand character imagery.

## Generation Prompt

Extract and faithfully retain the logo's friendly stylized plush 3D sheep: fluffy white curled fleece, peach face and pink ears, polished golden horns, black gold-rimmed sunglasses with the reference's white POP-style geometric emblems, cheerful open smile, emerald green scarf flowing right, and prominent thumbs-up hand. Remove badge, ring, plaques, all lettering, mountains, sun and clouds. Complete lower torso naturally in fluffy white fleece with the other brown hoof resting by the body. Upper-body portrait isolated on transparent alpha, no floor or rectangular shadow, no typography or new symbols. Match the original character design and rendering, with clean edges and detailed fleece.
