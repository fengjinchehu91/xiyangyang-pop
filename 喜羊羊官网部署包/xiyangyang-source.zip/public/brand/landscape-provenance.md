# Landscape Asset

- Final file: `landscape.webp` (1942 x 809 pixels, 168338 bytes).
- Source raster: `landscape-source.png`.
- Created with the built-in OpenAI image generation tool on 2026-10-18.
- Visual reference: the user-provided XIYANGYANG website preview, `exec-4d67e839-390d-4768-a18b-5cc18c751bb2.png`.
- The preview was used only as a landscape style reference. The generated image contains no page UI, words, logos, mascot, or transaction elements.
- Optimization: Sharp WebP, quality 84, effort 6, original dimensions retained.

Prompt: Create an ultra-wide 2.4:1 Chinese guochao website landscape, warm near-white #FAFBF7 sky, pale jade and blue-green karst mountains, airy traditional cloud wisps, restrained emerald mountains and evergreen trees along the lower edges. Keep the central and upper-left areas pale, low-contrast, and open for HTML text. Soft daylight, detailed lightly dimensional painted scenery. Avoid sheep, mascots, animals, people, logos, text, UI, coins, decorative orbs, frames, and watermarks.
